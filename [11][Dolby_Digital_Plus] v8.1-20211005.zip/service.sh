#!/system/bin/sh
se=$(getenforce)
case $se in 
     Permissive | permissive | 0 )
                was_permissive=1 
				;;
     Enforcing | enforcing | 1 )
                was_enforced=1
                setenforce 0 
				;;
 esac
 