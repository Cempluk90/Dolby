(
while [ "$(getprop sys.boot_completed)" != "1" ] && [ ! -d "/storage/emulated/0/Android" ]; do
  sleep 1
done

APP=$(pm list packages -3 | grep com.dolby.ds1appUI)

if [ ! -d "$MODPATH" ]; then
  if [ "$APP" ]; then
    pm uninstall com.dolby.ds1appUI
    rm -rf /data/data/com.dolby.ds1appUI
  fi
  rm $0
  exit 0
elif [ "$APP" ]; then
  STATUS="$(pm list packages -d | grep 'com.dolby.ds1appUI')"
  if [ -f "$MODPATH/disable" ] && [ ! "$STATUS" ]; then
    pm disable com.dolby.ds1appUI
  elif [ ! -f "$MODPATH/disable" ] && [ "$STATUS" ]; then
    pm enable com.dolby.ds1appUI
  fi
elif [ ! -f "$MODPATH/disable" ] && [ ! "$APP" ]; then
  pm install $MODPATH/system/priv-app/DsUI/DsUI.apk
  pm disable com.dolby.ds1appUI
  pm enable com.dolby.ds1appUI
fi
)&
